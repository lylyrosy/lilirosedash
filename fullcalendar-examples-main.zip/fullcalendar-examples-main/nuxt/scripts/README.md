
Util scripts for fullcalendar's monorepo
Not needed for real-world examples
