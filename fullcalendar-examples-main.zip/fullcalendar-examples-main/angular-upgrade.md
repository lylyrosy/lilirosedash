
To initialize a new project:

```
ng_version="15"
npx -p "@angular/cli@${ng_version}" ng new "@fullcalendar/angular${ng_version}-example" --directory "angular${ng_version}" --skip-install
```

Answer NO to routing. Answer CSS.

Update src/index.html `<title>` to match project name

Npm-script:
- "test"
- "test:dev"
- "clean"

Problems with tsconfig.json and .gitignore
