import Layout from '../components/layout'

export default function HomePage() {
  return (
    <Layout>
      Welcome! Click the links above
    </Layout>
  )
}
